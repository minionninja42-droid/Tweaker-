package com.example.homelauncher

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Живые обои: анимированный градиент или зацикленное видео из галереи. */
class LiveWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = E()

    inner class E : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val prefs = this@LiveWallpaperService.getSharedPreferences("home", Context.MODE_PRIVATE)
        private var player: MediaPlayer? = null
        private var surface: SurfaceHolder? = null
        private var visible = false

        // фон + три цвета «пятен»
        private val themes = arrayOf(
            arrayOf("#0B1026", "#2EE6A6", "#3B82F6", "#A855F7"),   // аврора
            arrayOf("#1A0B16", "#FF7A45", "#FF3D81", "#FFC857"),   // закат
            arrayOf("#04121F", "#0EA5E9", "#22D3EE", "#6366F1"),   // океан
            arrayOf("#0E0E10", "#6B7280", "#9CA3AF", "#374151")    // графит
        )

        private val frame = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible && !useVideo()) handler.postDelayed(this, 33)
            }
        }

        private fun videoFile() = File(this@LiveWallpaperService.filesDir, "live.mp4")
        private fun useVideo() = prefs.getInt("live_mode", 0) == 1 && videoFile().exists()

        private fun drawFrame() {
            val h = surface ?: return
            val c = try { h.lockCanvas() } catch (e: Throwable) { null } ?: return
            try {
                val w = c.width.toFloat()
                val ht = c.height.toFloat()
                val th = themes[prefs.getInt("live_theme", 0).coerceIn(0, themes.size - 1)]
                c.drawColor(Color.parseColor(th[0]))
                val t = SystemClock.uptimeMillis() / 1000f
                for (i in 1..3) {
                    val cx = w * (0.5f + 0.38f * sin(t * (0.25f + 0.08f * i) + i * 2.1f))
                    val cy = ht * (0.5f + 0.38f * cos(t * (0.20f + 0.06f * i) + i * 1.7f))
                    val r = max(w, ht) * 0.6f
                    val col = Color.parseColor(th[i])
                    paint.shader = RadialGradient(
                        cx, cy, r,
                        Color.argb(210, Color.red(col), Color.green(col), Color.blue(col)),
                        Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                        Shader.TileMode.CLAMP
                    )
                    c.drawCircle(cx, cy, r, paint)
                }
                paint.shader = null
            } finally {
                try { h.unlockCanvasAndPost(c) } catch (e: Throwable) { }
            }
        }

        private fun startVideo() {
            val s = surface ?: return
            stopVideo()
            try {
                player = MediaPlayer().apply {
                    setSurface(s.surface)
                    setDataSource(videoFile().path)
                    isLooping = true
                    setVolume(0f, 0f)
                    setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)
                    setOnPreparedListener { if (visible) it.start() }
                    prepareAsync()
                }
            } catch (e: Throwable) { player = null }
        }

        private fun stopVideo() {
            try { player?.release() } catch (e: Throwable) { }
            player = null
        }

        private fun refresh() {
            handler.removeCallbacks(frame)
            if (visible) {
                if (useVideo()) {
                    if (player == null) startVideo() else try { player?.start() } catch (e: Throwable) { }
                } else {
                    stopVideo()
                    handler.post(frame)
                }
            } else {
                try { player?.pause() } catch (e: Throwable) { }
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            surface = holder
            refresh()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            refresh()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(frame)
            stopVideo()
            surface = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            handler.removeCallbacks(frame)
            stopVideo()
            super.onDestroy()
        }
    }
}
