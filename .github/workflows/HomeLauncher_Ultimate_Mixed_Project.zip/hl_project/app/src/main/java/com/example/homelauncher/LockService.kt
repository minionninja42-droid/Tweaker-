package com.example.homelauncher

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * Показывает свой экран блокировки.
 * Режим 0 (по умолчанию, совместим с AOD): экран блокировки появляется, когда вы будите телефон.
 * Режим 1: сразу после выключения экрана (с задержкой, чтобы AOD успел запуститься).
 */
class LockService : Service() {

    private val handler = Handler(Looper.getMainLooper())

    private fun showLock(c: Context) {
        val s = Intent(c, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { c.startActivity(s) } catch (e: Throwable) { }
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val mode = c.getSharedPreferences("home", Context.MODE_PRIVATE).getInt("lk_mode", 0)
            val km = c.getSystemService(KeyguardManager::class.java)
            val pm = c.getSystemService(PowerManager::class.java)
            when (i.action) {
                Intent.ACTION_SCREEN_ON -> if (mode == 0 && km.isKeyguardLocked) showLock(c)
                Intent.ACTION_SCREEN_OFF -> if (mode == 1) {
                    handler.postDelayed({ if (!pm.isInteractive) showLock(c) }, 1500)
                }
            }
        }
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lock", "Экран блокировки", NotificationManager.IMPORTANCE_MIN))
        return Notification.Builder(this, "lock")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Свой экран блокировки включён")
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif())
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(rcv, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(rcv) } catch (e: Throwable) { }
        super.onDestroy()
    }
}
