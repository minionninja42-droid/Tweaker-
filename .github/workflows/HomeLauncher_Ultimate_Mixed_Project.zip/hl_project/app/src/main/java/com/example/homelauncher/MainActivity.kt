package com.example.homelauncher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.io.File
import org.json.JSONArray
import rikka.shizuku.Shizuku
import org.json.JSONObject
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.ceil

/** Страница рабочего стола: сетка ячеек, элементы ставятся по координатам. */
class CellLayout(ctx: Context, private val cols: Int, private val rows: Int) : ViewGroup(ctx) {
    class LP(var x: Int, var y: Int, var w: Int, var h: Int) :
        ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    var lastX = 0f
    var lastY = 0f

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?) = p is LP

    override fun onMeasure(ws: Int, hs: Int) {
        val w = View.MeasureSpec.getSize(ws)
        val h = View.MeasureSpec.getSize(hs)
        setMeasuredDimension(w, h)
        val cw = w / cols
        val ch = h / rows
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LP
            c.measure(
                View.MeasureSpec.makeMeasureSpec(cw * lp.w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(ch * lp.h, View.MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l) / cols
        val ch = (b - t) / rows
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LP
            c.layout(lp.x * cw, lp.y * ch, (lp.x + lp.w) * cw, (lp.y + lp.h) * ch)
        }
    }

    fun cellX(x: Float) = (x / (width / cols)).toInt().coerceIn(0, cols - 1)
    fun cellY(y: Float) = (y / (height / rows)).toInt().coerceIn(0, rows - 1)
}

/** «Стекло»: кусок размытых обоев под панелью + белая вуаль, блик и светлая рамка. */
class GlassDrawable(
    private val v: View,
    private val radius: Float,
    private val blur: Bitmap?,
    private val tint: Int
) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val loc = IntArray(2)

    override fun draw(c: Canvas) {
        val b = bounds
        val rect = RectF(b)
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        if (blur != null) {
            v.getLocationOnScreen(loc)
            val dm = v.resources.displayMetrics
            val sx = blur.width.toFloat() / dm.widthPixels
            val sy = blur.height.toFloat() / dm.heightPixels
            val src = Rect(
                (loc[0] * sx).toInt(), (loc[1] * sy).toInt(),
                ((loc[0] + b.width()) * sx).toInt(), ((loc[1] + b.height()) * sy).toInt()
            )
            c.drawBitmap(blur, src, b, null)
        }
        p.style = Paint.Style.FILL
        p.color = tint
        c.drawRect(rect, p)
        p.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            Color.argb(70, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )
        c.drawRect(rect, p)
        p.shader = null
        c.restore()
        if (radius > 0f) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f
            p.color = Color.argb(120, 255, 255, 255)
            c.drawPath(path, p)
        }
    }

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Рамка поверх элемента: тяните за середину — двигать, за белые точки — менять размер (только виджеты). */
class ResizeOverlay(
    ctx: Context,
    private val resizable: Boolean,
    private val onDrag: (dx: Float, dy: Float, rw: Boolean, rh: Boolean, mv: Boolean, done: Boolean) -> Unit
) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var sx = 0f
    private var sy = 0f
    private var rw = false
    private var rh = false
    private var mv = false

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        p.style = Paint.Style.FILL
        p.color = Color.argb(40, 255, 255, 255)
        c.drawRoundRect(RectF(2 * d, 2 * d, width - 2 * d, height - 2 * d), 12 * d, 12 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3 * d
        p.color = Color.WHITE
        c.drawRoundRect(RectF(2 * d, 2 * d, width - 2 * d, height - 2 * d), 12 * d, 12 * d, p)
        if (resizable) {
            p.style = Paint.Style.FILL
            c.drawCircle(width - 2 * d, height / 2f, 10 * d, p)
            c.drawCircle(width / 2f, height - 2 * d, 10 * d, p)
            c.drawCircle(width - 2 * d, height - 2 * d, 13 * d, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val d = resources.displayMetrics.density
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                parent.requestDisallowInterceptTouchEvent(true)
                sx = e.rawX; sy = e.rawY
                rw = resizable && e.x > width - 44 * d
                rh = resizable && e.y > height - 44 * d
                mv = !rw && !rh
            }
            MotionEvent.ACTION_MOVE -> onDrag(e.rawX - sx, e.rawY - sy, rw, rh, mv, false)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onDrag(e.rawX - sx, e.rawY - sy, rw, rh, mv, true)
        }
        return true
    }
}

/** Плитка иконки: заливка + рамка с градиентом (подсветка или тень), как в настройках «Icon pack» из видео. */
class IconTileDrawable(
    private val radius: Float,
    private val fillAlpha: Int,
    private val borderStyle: Int,   // 0 — нет, 1 — подсветка, 2 — тень
    private val borderPx: Float,
    private val intensity: Int,     // 0..100
    private val angleDeg: Int
) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(c: Canvas) {
        val b = bounds
        val r = RectF(b)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, r.top, 0f, r.bottom,
            Color.argb(fillAlpha, 255, 255, 255),
            Color.argb((fillAlpha * 0.82f).toInt(), 232, 232, 238),
            Shader.TileMode.CLAMP
        )
        c.drawRoundRect(r, radius, radius, p)
        p.shader = null
        if (borderStyle != 0 && borderPx > 0f) {
            val a = (intensity.coerceIn(0, 100) * 255 / 100)
            val rad = Math.toRadians(angleDeg.toDouble())
            val dx = Math.cos(rad).toFloat()
            val dy = Math.sin(rad).toFloat()
            val cx = r.centerX()
            val cy = r.centerY()
            val len = maxOf(r.width(), r.height()) / 2f
            val col = if (borderStyle == 1) Color.argb(a, 255, 255, 255) else Color.argb(a, 0, 0, 0)
            val none = if (borderStyle == 1) Color.argb(0, 255, 255, 255) else Color.argb(0, 0, 0, 0)
            p.shader = LinearGradient(cx - dx * len, cy - dy * len, cx + dx * len, cy + dy * len, col, none, Shader.TileMode.CLAMP)
            p.style = Paint.Style.STROKE
            p.strokeWidth = borderPx
            val h = borderPx / 2f
            c.drawRoundRect(RectF(r.left + h, r.top + h, r.right - h, r.bottom - h), radius, radius, p)
            p.shader = null
        }
    }

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

class MainActivity : Activity() {

    data class App(val pkg: String, val label: String, val icon: Drawable, val mono: Drawable? = null)
    data class Item(val type: String, var page: Int, var x: Int, var y: Int, var w: Int, var h: Int, var ref: String)

    // Сетка рабочего стола настраивается отдельно от сетки списка приложений.
    private fun homeCols() = prefs.getInt("home_cols", 4).coerceIn(3, 6)
    private fun homeRows() = prefs.getInt("home_rows", 6).coerceIn(4, 8)

    private lateinit var prefs: SharedPreferences
    private lateinit var awm: AppWidgetManager
    private lateinit var host: AppWidgetHost
    private lateinit var root: FrameLayout
    private lateinit var pager: ViewPager
    private lateinit var dots: TextView
    private lateinit var dock: LinearLayout
    private lateinit var clockHolder: FrameLayout
    private lateinit var askPill: TextView
    private lateinit var editBar: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var adapter: AppAdapter

    private val all = mutableListOf<App>()
    private val shown = mutableListOf<App>()
    private val items = mutableListOf<Item>()
    private var pageCount = 2
    private var moving: Item? = null
    private var resizing: Item? = null
    private var pendingId = -1
    private var wallTarget = 0
    private var glassBmp: Bitmap? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private var lastTx = 0
    private var lastTy = 0

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) { lastTx = e.rawX.toInt(); lastTy = e.rawY.toInt() }
        return super.dispatchTouchEvent(e)
    }

    /** Запуск приложения с анимацией «разворачивания» из места нажатия. */
    private fun launch(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        if (prefs.getBoolean("open_anim", true)) {
            try {
                val loc = IntArray(2)
                root.getLocationOnScreen(loc)
                val o = ActivityOptions.makeScaleUpAnimation(root, lastTx - loc[0], lastTy - loc[1], 1, 1)
                startActivity(intent, o.toBundle())
                return
            } catch (e: Throwable) { }
        }
        startActivity(intent)
    }

    /** Свой DPI («наименьшая ширина») только для лаунчера, без Shizuku. */
    override fun attachBaseContext(newBase: Context) {
        val w = newBase.getSharedPreferences("home", Context.MODE_PRIVATE).getInt("target_w", 0)
        if (w >= 300) {
            val dm = newBase.resources.displayMetrics
            val px = minOf(dm.widthPixels, dm.heightPixels)
            val cfg = Configuration(newBase.resources.configuration)
            cfg.densityDpi = 160 * px / w
            super.attachBaseContext(newBase.createConfigurationContext(cfg))
        } else super.attachBaseContext(newBase)
    }

    // ================= данные =================

    private fun loadItems() {
        items.clear()
        val arr = JSONArray(prefs.getString("items", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val w = o.getInt("w").coerceIn(1, homeCols())
            val h = o.getInt("h").coerceIn(1, homeRows())
            val x = o.getInt("x").coerceIn(0, homeCols() - w)
            val y = o.getInt("y").coerceIn(0, homeRows() - h)
            items.add(Item(o.getString("t"), o.getInt("p"), x, y, w, h, o.getString("r")))
        }
    }

    private fun saveItems() {
        val arr = JSONArray()
        for (it in items) {
            arr.put(JSONObject().put("t", it.type).put("p", it.page).put("x", it.x).put("y", it.y)
                .put("w", it.w).put("h", it.h).put("r", it.ref))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    private fun dockList() = (prefs.getString("dock", "") ?: "").split(",").filter { it.isNotEmpty() }
    private fun saveDock(l: List<String>) = prefs.edit().putString("dock", l.joinToString(",")).apply()

    private fun normalizeHomeItems() {
        val cols = homeCols(); val rows = homeRows()
        items.forEach { item ->
            item.w = item.w.coerceIn(1, cols)
            item.h = item.h.coerceIn(1, rows)
            item.x = item.x.coerceIn(0, cols - item.w)
            item.y = item.y.coerceIn(0, rows - item.h)
        }
        saveItems()
    }

    private fun isFree(page: Int, x: Int, y: Int, w: Int, h: Int, ignore: Item?): Boolean {
        if (x < 0 || y < 0 || x + w > homeCols() || y + h > homeRows()) return false
        return items.none {
            it !== ignore && it.page == page &&
                x < it.x + it.w && it.x < x + w && y < it.y + it.h && it.y < y + h
        }
    }

    private fun placeNew(type: String, ref: String, w: Int, h: Int): Boolean {
        val cur = pager.currentItem
        val order = listOf(cur) + (0 until pageCount).filter { it != cur }
        for (p in order) {
            for (y in 0..(homeRows() - h)) for (x in 0..(homeCols() - w)) {
                if (isFree(p, x, y, w, h, null)) {
                    items.add(Item(type, p, x, y, w, h, ref))
                    saveItems()
                    return true
                }
            }
        }
        toast("Нет места на рабочем столе")
        return false
    }

    private fun loadApps() {
        thread {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = packageManager.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val ic = it.loadIcon(packageManager)
                    val mono = if (Build.VERSION.SDK_INT >= 33 && ic is AdaptiveIconDrawable) ic.monochrome else null
                    App(it.activityInfo.packageName, it.loadLabel(packageManager).toString(), ic, mono)
                }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                val changed = list.map { it.pkg } != all.map { it.pkg }
                all.clear(); all.addAll(list)
                // чистим удалённые приложения и виджеты
                val before = items.size
                items.removeAll { i ->
                    (i.type == "app" && all.none { it.pkg == i.ref }) ||
                        (i.type == "widget" && awm.getAppWidgetInfo(i.ref.toInt()) == null)
                }
                if (items.size != before) saveItems()
                applyFilter(); buildDock()
                if (changed || items.size != before) refreshHome()
            }
        }
    }

    private fun applyFilter() {
        val hidden = prefs.getStringSet("hidden", emptySet())!!
        val q = search.text.toString().trim().lowercase(Locale.ROOT)
        shown.clear()
        val matches = all.filter { app ->
            app.pkg !in hidden && (
                q.isEmpty() ||
                app.label.lowercase(Locale.ROOT).contains(q) ||
                app.pkg.lowercase(Locale.ROOT).contains(q)
            )
        }
        val sortMode = prefs.getInt("app_sort", 0)
        shown.addAll(when (sortMode) {
            1 -> matches.sortedWith(compareBy<App> { !it.label.lowercase(Locale.ROOT).startsWith(q) }
                .thenByDescending { it.label.lowercase(Locale.ROOT) })
            2 -> matches.sortedBy { it.pkg.lowercase(Locale.ROOT) }
            else -> matches.sortedWith(compareBy<App> { !it.label.lowercase(Locale.ROOT).startsWith(q) }
                .thenBy { it.label.lowercase(Locale.ROOT) })
        })
        adapter.notifyDataSetChanged()
    }

    // ================= рабочий стол =================

    private fun refreshHome() {
        pager.adapter?.notifyDataSetChanged()
        updateDots()
    }

    private fun updateDots() {
        dots.text = (0 until pageCount).joinToString("  ") { if (it == pager.currentItem) "●" else "○" }
    }

    private fun iconImage(a: App, size: Int): ImageView {
        val iv = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(size, size) }
        val theme = prefs.getInt("theme", 1)
        if (theme == 5 || prefs.getBoolean("realme", false)) {
            val pad = (size * 0.2f).toInt()
            iv.setPadding(pad, pad, pad, pad)
            iv.background = IconTileDrawable(
                size * prefs.getInt("ic_round", 30) / 100f,
                prefs.getInt("tile_alpha", 238),
                prefs.getInt("ib_style", 1),
                dp(1) * prefs.getInt("ib_width", 3) / 2f,
                prefs.getInt("ib_int", 100),
                prefs.getInt("ib_angle", 90)
            )
            val mono = a.mono
            if (mono != null) {
                iv.setImageDrawable(mono)
                iv.setColorFilter(Color.parseColor("#4A4A50"))
            } else {
                iv.setImageDrawable(a.icon)
                iv.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
            }
        } else iv.setImageDrawable(a.icon)
        if (theme in 1..4 || theme == 9) {
            iv.background = GradientDrawable().apply {
                cornerRadius = size * 0.23f
                setColor(if (theme == 3) Color.BLACK else Color.TRANSPARENT)
            }
            iv.clipToOutline = true
        }
        return iv
    }

    private fun iconView(a: App, onClick: () -> Unit, onLong: () -> Unit): View {
        val size = dp(prefs.getInt("icon", 56))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
            setOnLongClickListener { onLong(); true }
        }
        col.addView(iconImage(a, size))
        if (prefs.getBoolean("labels", true)) {
            col.addView(TextView(this).apply {
                text = a.label; setTextColor(if (prefs.getInt("theme", 1) == 1) Color.WHITE else Color.WHITE); textSize = prefs.getInt("label_size", 12).toFloat()
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
                setShadowLayer(4f, 0f, 1f, Color.BLACK)
                setPadding(dp(2), dp(4), dp(2), 0)
            })
        }
        return col
    }

    private fun makeView(item: Item): View? {
        if (item.type == "app") {
            val a = all.firstOrNull { it.pkg == item.ref } ?: return null
            return iconView(a, { launch(a.pkg) }, { itemMenu(item) })
        }
        if (item.type == "folder") {
            val folderParts = item.ref.split("|", limit = 2)
            val folderName = folderParts.firstOrNull()?.takeIf { it.isNotBlank() } ?: "Папка"
            val pkgs = folderParts.getOrNull(1).orEmpty().split(";").filter { it.isNotBlank() }
            val theme = prefs.getInt("theme", 1)
            val tile = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(if (theme in 1..3) 20 else 16).toFloat()
                    setColor(when (theme) {
                        2 -> Color.argb(150, 35, 35, 40)
                        3 -> Color.argb(190, 8, 8, 10)
                        4 -> Color.argb(105, 255, 255, 255)
                        7 -> Color.argb(190, 35, 48, 65)
                        8 -> Color.argb(190, 48, 34, 62)
                        9 -> Color.argb(150, 245, 248, 255)
                        else -> Color.argb(190, 235, 235, 242)
                    })
                    if (theme == 4) setStroke(dp(1), Color.argb(100, 255, 255, 255))
                }
                setOnClickListener { openFolder(item) }
                setOnLongClickListener { itemMenu(item); true }
            }
            val preview = GridLayout(this).apply {
                rowCount = 2; columnCount = 2
                setPadding(dp(7), dp(7), dp(7), dp(7))
            }
            pkgs.take(4).forEach { pkg ->
                all.firstOrNull { it.pkg == pkg }?.let { a ->
                    preview.addView(iconImage(a, dp(23)), ViewGroup.LayoutParams(dp(25), dp(25)))
                }
            }
            tile.addView(preview, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                addView(tile, LinearLayout.LayoutParams(dp(58), dp(58)))
                addView(TextView(this@MainActivity).apply {
                    text = folderName; textSize = 11f; gravity = Gravity.CENTER
                    setTextColor(if (theme == 1 || theme == 5) Color.WHITE else Color.WHITE)
                    maxLines = 1
                })
            }
        }
        val id = item.ref.toInt()
        val info = awm.getAppWidgetInfo(id) ?: return null
        val hv = host.createView(this, id, info)
        val dm = resources.displayMetrics
        val wDp = (dm.widthPixels / homeCols() * item.w / dm.density).toInt()
        val hDp = (dm.heightPixels * 0.62f / homeRows() * item.h / dm.density).toInt()
        hv.updateAppWidgetSize(Bundle(), wDp, hDp, wDp, hDp)
        hv.setOnLongClickListener { itemMenu(item); true }
        return hv
    }

    private fun buildPage(pos: Int): View {
        val cl = CellLayout(this, homeCols(), homeRows())
        cl.isClickable = true
        cl.isLongClickable = true
        cl.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) { cl.lastX = e.x; cl.lastY = e.y }
            false
        }
        cl.setOnLongClickListener { homeMenu(); true }
        cl.setOnClickListener {
            if (resizing != null) {
                resizing = null; refreshHome()
            } else {
                val m = moving
                if (m != null) moveTo(m, pos, cl.cellX(cl.lastX), cl.cellY(cl.lastY))
            }
        }
        val views = java.util.IdentityHashMap<Item, View>()
        for (item in items.filter { it.page == pos }) {
            makeView(item)?.let {
                views[item] = it
                cl.addView(it, CellLayout.LP(item.x, item.y, item.w, item.h))
            }
        }
        val rz = resizing
        if (rz != null && rz.page == pos) {
            val wv = views[rz]
            val ovLp = CellLayout.LP(rz.x, rz.y, rz.w, rz.h)
            var bw = rz.w
            var bh = rz.h
            var bx = rz.x
            var by = rz.y
            val ov = ResizeOverlay(this, rz.type == "widget") { dx, dy, rw, rh, mv, done ->
                val cw = maxOf(1, cl.width / homeCols())
                val ch = maxOf(1, cl.height / homeRows())
                if (mv) {
                    val nx = (bx + Math.round(dx / cw)).coerceIn(0, homeCols() - rz.w)
                    val ny = (by + Math.round(dy / ch)).coerceIn(0, homeRows() - rz.h)
                    if ((nx != rz.x || ny != rz.y) && isFree(rz.page, nx, ny, rz.w, rz.h, rz)) {
                        rz.x = nx; rz.y = ny
                        ovLp.x = nx; ovLp.y = ny
                        (wv?.layoutParams as? CellLayout.LP)?.let { lp -> lp.x = nx; lp.y = ny }
                        cl.requestLayout()
                    }
                } else {
                    val nw = if (rw) (bw + Math.round(dx / cw)).coerceIn(1, homeCols() - rz.x) else bw
                    val nh = if (rh) (bh + Math.round(dy / ch)).coerceIn(1, homeRows() - rz.y) else bh
                    if ((nw != rz.w || nh != rz.h) && isFree(rz.page, rz.x, rz.y, nw, nh, rz)) {
                        rz.w = nw; rz.h = nh
                        ovLp.w = nw; ovLp.h = nh
                        (wv?.layoutParams as? CellLayout.LP)?.let { lp -> lp.w = nw; lp.h = nh }
                        cl.requestLayout()
                    }
                }
                if (done) {
                    bw = rz.w; bh = rz.h; bx = rz.x; by = rz.y
                    saveItems(); refreshHome()
                }
            }
            cl.addView(ov, ovLp)
        }
        return cl
    }

    inner class PagesAdapter : PagerAdapter() {
        override fun getCount() = pageCount
        override fun isViewFromObject(v: View, obj: Any) = v === obj
        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val v = buildPage(position)
            container.addView(v)
            return v
        }
        override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
            container.removeView(obj as View)
        }
        override fun getItemPosition(obj: Any) = POSITION_NONE
    }

    private fun moveTo(item: Item, page: Int, cx: Int, cy: Int) {
        val x = minOf(cx, homeCols() - item.w)
        val y = minOf(cy, homeRows() - item.h)
        if (isFree(page, x, y, item.w, item.h, item)) {
            item.page = page; item.x = x; item.y = y
            moving = null
            saveItems(); refreshHome()
        } else toast("Место занято, выберите другое")
    }

    private fun itemMenu(item: Item) {
        val widget = item.type == "widget"
        val opts = arrayOf(
            if (widget) "Двигать пальцем / менять размер" else "Двигать пальцем",
            "На другую страницу",
            if (widget) "Удалить" else "Убрать с рабочего стола"
        )
        AlertDialog.Builder(this).setItems(opts) { _, i ->
            when (i) {
                0 -> {
                    resizing = item; refreshHome()
                    toast(if (widget) "Тяните за середину, чтобы двигать, за точки — менять размер. Нажмите вне рамки, чтобы закончить"
                          else "Тяните иконку пальцем. Нажмите вне рамки, чтобы закончить")
                }
                1 -> { moving = item; toast("Нажмите на свободное место (можно на другой странице)") }
                else -> {
                    if (widget) host.deleteAppWidgetId(item.ref.toInt())
                    items.remove(item); saveItems(); refreshHome()
                }
            }
        }.show()
    }

    private fun resizeDialog(item: Item) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val ws = (1..homeCols()).toList()
        val hs = (1..homeRows()).toList()
        val sw = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ws.map { "Ширина: $it" })
            setSelection(item.w - 1)
        }
        val sh = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, hs.map { "Высота: $it" })
            setSelection(item.h - 1)
        }
        box.addView(sw); box.addView(sh)
        AlertDialog.Builder(this).setTitle("Размер виджета (в ячейках)").setView(box)
            .setPositiveButton("Применить") { _, _ ->
                val nw = ws[sw.selectedItemPosition]
                val nh = hs[sh.selectedItemPosition]
                val nx = minOf(item.x, homeCols() - nw)
                val ny = minOf(item.y, homeRows() - nh)
                if (isFree(item.page, nx, ny, nw, nh, item)) {
                    item.w = nw; item.h = nh; item.x = nx; item.y = ny
                    saveItems(); refreshHome()
                } else toast("Не помещается, место занято")
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun homeMenu() {
        editBar.visibility = View.VISIBLE
    }

    private fun pagesDialog() {
        AlertDialog.Builder(this).setItems(arrayOf("Добавить страницу", "Удалить эту страницу")) { _, i ->
            if (i == 0) {
                pageCount++
                prefs.edit().putInt("pages", pageCount).apply()
                refreshHome()
                pager.currentItem = pageCount - 1
            } else removePage(pager.currentItem)
        }.show()
    }

    private fun removePage(p: Int) {
        if (pageCount <= 1) { toast("Нельзя удалить единственную страницу"); return }
        for (i in items.filter { it.page == p && it.type == "widget" }) host.deleteAppWidgetId(i.ref.toInt())
        items.removeAll { it.page == p }
        items.filter { it.page > p }.forEach { it.page-- }
        pageCount--
        prefs.edit().putInt("pages", pageCount).apply()
        saveItems(); refreshHome()
    }

    // ================= виджеты =================

    private fun pickWidget() {
        val provs = awm.installedProviders.sortedBy { it.loadLabel(packageManager).lowercase() }
        val names = provs.map { it.loadLabel(packageManager) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Выберите виджет").setItems(names) { _, i ->
            val pr = provs[i]
            val id = host.allocateAppWidgetId()
            pendingId = id
            if (awm.bindAppWidgetIdIfAllowed(id, pr.provider)) {
                afterBind(id)
            } else {
                val bind = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, pr.provider)
                startActivityForResult(bind, 88)
            }
        }.setNegativeButton("Отмена", null).show()
    }

    private fun afterBind(id: Int) {
        val cfg = awm.getAppWidgetInfo(id)?.configure
        if (cfg != null) {
            try {
                val c = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                    .setComponent(cfg).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                startActivityForResult(c, 89)
            } catch (e: Throwable) { addWidget(id) }
        } else addWidget(id)
    }

    private fun addWidget(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info == null) { host.deleteAppWidgetId(id); return }
        val dm = resources.displayMetrics
        val cellW = dm.widthPixels / homeCols()
        val cellH = (dm.heightPixels * 0.62f / homeRows()).toInt()
        val w = ceil(info.minWidth.toFloat() / cellW).toInt().coerceIn(1, homeCols())
        val h = ceil(info.minHeight.toFloat() / cellH).toInt().coerceIn(1, homeRows())
        if (placeNew("widget", id.toString(), w, h)) {
            refreshHome()
            pager.currentItem = items.last().page
        } else host.deleteAppWidgetId(id)
    }

    // ================= док и меню приложений =================

    private fun buildDock() {
        dock.removeAllViews()
        val size = dp(prefs.getInt("icon", 56))
        val dockLimit = prefs.getInt("dock_slots", 4).coerceIn(3, 6)
        for (p in dockList().take(dockLimit)) {
            val a = all.firstOrNull { it.pkg == p } ?: continue
            val cell = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, size, 1f)
                setOnClickListener { launch(a.pkg) }
                setOnLongClickListener { appMenu(a); true }
            }
            cell.addView(iconImage(a, size).apply {
                layoutParams = FrameLayout.LayoutParams(size, size, Gravity.CENTER)
            })
            dock.addView(cell)
        }
        dock.addView(TextView(this).apply {
            text = "▦"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, size, 1f)
            setOnClickListener { openDrawer() }
        })
    }

    private fun openFolder(item: Item) {
        val parts = item.ref.split("|", limit = 2)
        val apps = parts.getOrNull(1).orEmpty().split(";").mapNotNull { pkg -> all.firstOrNull { it.pkg == pkg } }
        val names = apps.map { it.label }.toTypedArray()
        if (apps.isEmpty()) { toast("Папка пуста"); return }
        AlertDialog.Builder(this).setTitle("Папка")
            .setItems(names) { _, which -> launch(apps[which].pkg) }
            .setPositiveButton("Изменить") { _, _ -> editFolder(item) }
            .setNegativeButton("Закрыть", null).show()
    }

    private fun editFolder(item: Item) {
        val parts = item.ref.split("|", limit = 2)
        val currentName = parts.firstOrNull()?.takeIf { it.isNotBlank() } ?: "Папка"
        val current = parts.getOrNull(1).orEmpty().split(";").filter { it.isNotBlank() }.toMutableSet()
        val labels = all.map { it.label }.toTypedArray()
        val selected = all.map { it.pkg in current }.toBooleanArray()
        val input = EditText(this).apply { setText(currentName); hint = "Название папки" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(input)
        val list = ListView(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, labels)
        list.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        selected.forEachIndexed { i, yes -> list.setItemChecked(i, yes) }
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)))
        AlertDialog.Builder(this).setTitle("Редактор папки").setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                val chosen = all.filterIndexed { i, _ -> list.isItemChecked(i) }.map { it.pkg }
                if (chosen.isEmpty()) { items.remove(item) } else item.ref = "${input.text.toString().ifBlank { "Папка" }}|${chosen.joinToString(";")}"
                saveItems(); refreshHome()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun createFolder(a: App) {
        val selected = all.map { it.pkg == a.pkg }.toBooleanArray()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { setText("Папка"); hint = "Название папки" }
        val list = ListView(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, all.map { it.label })
        list.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        selected.forEachIndexed { i, yes -> list.setItemChecked(i, yes) }
        box.addView(name)
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280)))
        AlertDialog.Builder(this).setTitle("Новая папка").setView(box)
            .setPositiveButton("Создать") { _, _ ->
                val chosen = all.filterIndexed { i, _ -> list.isItemChecked(i) }.map { it.pkg }
                if (chosen.isNotEmpty() && placeNew("folder", "${name.text.toString().ifBlank { "Папка" }}|${chosen.joinToString(";")}", 1, 1)) {
                    saveItems(); refreshHome(); toast("Папка создана")
                }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun appMenu(a: App) {
        val dockL = dockList()
        val inDock = a.pkg in dockL
        val opts = arrayOf("На рабочий стол", if (inDock) "Убрать из дока" else "В док", "Создать папку", "Скрыть", "О приложении", "Удалить")
        AlertDialog.Builder(this).setTitle(a.label).setItems(opts) { _, i ->
            when (i) {
                0 -> { if (placeNew("app", a.pkg, 1, 1)) { refreshHome(); closeDrawer(); toast("Добавлено") } }
                1 -> if (inDock) saveDock(dockL - a.pkg)
                     else if (dockL.size >= prefs.getInt("dock_slots", 4).coerceIn(3, 6)) toast("Док заполнен")
                     else saveDock(dockL + a.pkg)
                2 -> createFolder(a)
                3 -> prefs.edit().putStringSet("hidden", prefs.getStringSet("hidden", emptySet())!!.toMutableSet().apply { add(a.pkg) }).apply()
                4 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                5 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            }
            buildDock(); applyFilter()
        }.show()
    }

    private fun openDrawer() { search.setText(""); drawer.visibility = View.VISIBLE; windowBlur(true) }
    private fun closeDrawer() { drawer.visibility = View.GONE; windowBlur(false) }

    // ================= стекло =================

    private fun glassFile() = File(filesDir, "glass.jpg")

    private fun saveJpeg(bmp: Bitmap, name: String) {
        try { File(filesDir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) } } catch (e: Throwable) { }
    }

    private fun startLock(on: Boolean) {
        val i = Intent(this, LockService::class.java)
        try { if (on) startForegroundService(i) else stopService(i) } catch (e: Throwable) { }
    }

    private fun loadGlass() {
        glassBmp = try {
            if (glassFile().exists()) BitmapFactory.decodeFile(glassFile().path) else null
        } catch (e: Throwable) { null }
    }

    private fun saveGlass(src: Bitmap, name: String = "glass.jpg") {
        try {
            var cur = src
            val w = src.width
            val h = src.height
            while (cur.width > w / 24) {
                cur = Bitmap.createScaledBitmap(cur, maxOf(1, cur.width / 2), maxOf(1, cur.height / 2), true)
            }
            while (cur.width < w) {
                cur = Bitmap.createScaledBitmap(cur, minOf(w, cur.width * 2), minOf(h, cur.height * 2), true)
            }
            File(filesDir, name).outputStream().use { cur.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        } catch (e: Throwable) { }
    }

    private fun applyGlass() {
        val a = prefs.getInt("glass", 45)
        val dockAlpha = prefs.getInt("dock_alpha", 62).coerceIn(0, 100)
        val tint = Color.argb(a, 255, 255, 255)
        if (glassBmp != null) {
            val dockTint = Color.argb(a * dockAlpha / 100, 255, 255, 255)
            dock.background = GlassDrawable(dock, dp(28).toFloat(), glassBmp, dockTint)
        }
        search.background = GlassDrawable(search, dp(24).toFloat(), glassBmp, tint)
        val theme = prefs.getInt("theme", 1)
        val drawerTint = when (theme) {
            1, 9 -> Color.argb(155, 238, 242, 250)
            2 -> Color.argb(205, 22, 24, 30)
            3 -> Color.argb(235, 0, 0, 0)
            7 -> Color.argb(215, 17, 25, 38)
            8 -> Color.argb(215, 28, 20, 38)
            10 -> Color.argb(215, 22, 31, 45)
            else -> Color.argb(190, 12, 14, 20)
        }
        drawer.background = if (glassBmp != null)
            GlassDrawable(drawer, 0f, glassBmp, drawerTint)
        else ColorDrawable(drawerTint)
        search.setTextColor(if (theme == 1 || theme == 9) Color.DKGRAY else Color.WHITE)
        search.setHintTextColor(if (theme == 1 || theme == 9) Color.GRAY else Color.LTGRAY)
    }

    private fun windowBlur(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 31) {
            try { window.setBackgroundBlurRadius(if (on && prefs.getBoolean("wblur", true)) dp(24) else 0) } catch (e: Throwable) { }
        }
    }

    // ================= настройки и обои =================

    private fun applySettings() {
        grid.numColumns = prefs.getInt("cols", 4)
        root.setBackgroundColor(Color.argb(prefs.getInt("dim", 0), 0, 0, 0))
        adapter.notifyDataSetChanged()
        buildDock()
        val theme = prefs.getInt("theme", 1)
        dock.background = GradientDrawable().apply {
            cornerRadius = dp(if (theme in 1..4 || theme == 9) 30 else 24).toFloat()
            val baseDock = when (theme) {
                1 -> Color.rgb(245, 245, 250)
                2 -> Color.rgb(30, 30, 36)
                3 -> Color.BLACK
                4 -> Color.WHITE
                5 -> Color.rgb(18, 18, 22)
                6 -> Color.rgb(32, 32, 40)
                7 -> Color.rgb(24, 31, 42)
                8 -> Color.rgb(30, 24, 40)
                9 -> Color.rgb(245, 248, 255)
                10 -> Color.rgb(28, 36, 48)
                else -> Color.BLACK
            }
            setColor(Color.argb(prefs.getInt("dock_alpha", 62) * 255 / 100, Color.red(baseDock), Color.green(baseDock), Color.blue(baseDock)))
            if (theme == 4) setStroke(dp(1), Color.argb(130, 255, 255, 255))
        }
        applyGlass()
        val rm = prefs.getBoolean("realme", false) || theme == 5
        clockHolder.removeAllViews()
        if (rm) {
            clockHolder.addView(
                GlassClockView(this, false, false, prefs.getBoolean("lk_24", true), prefs.getBoolean("hclock_light", false)),
                FrameLayout.LayoutParams(dp(190), dp(104), Gravity.CENTER_HORIZONTAL)
            )
        }
        askPill.visibility = if (rm) View.VISIBLE else View.GONE
        refreshHome()
    }

    private fun settingsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        fun label(t: String) = TextView(this@MainActivity).apply { text = t; setPadding(0, dp(14), 0, dp(2)) }
        val colsOpts = listOf(3, 4, 5, 6)
        val cols = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, colsOpts.map { "$it" })
            setSelection(colsOpts.indexOf(prefs.getInt("cols", 4)).coerceAtLeast(0))
        }
        val homeColsOpts = (3..6).toList()
        val homeColsPick = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, homeColsOpts.map { "$it" })
            setSelection(homeColsOpts.indexOf(homeCols()).coerceAtLeast(0))
        }
        val homeRowsOpts = (4..8).toList()
        val homeRowsPick = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, homeRowsOpts.map { "$it" })
            setSelection(homeRowsOpts.indexOf(homeRows()).coerceAtLeast(0))
        }
        val dockSlotsOpts = (3..6).toList()
        val dockSlotsPick = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, dockSlotsOpts.map { "$it" })
            setSelection(dockSlotsOpts.indexOf(prefs.getInt("dock_slots", 4)).coerceAtLeast(0))
        }
        val labelSize = SeekBar(this).apply { max = 8; progress = prefs.getInt("label_size", 12) - 10 }
        val dockAlpha = SeekBar(this).apply { max = 100; progress = prefs.getInt("dock_alpha", 62) }
        val sortNames = listOf("По алфавиту (А–Я)", "Сначала совпадения", "По имени пакета")
        val sortPick = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, sortNames)
            setSelection(prefs.getInt("app_sort", 0).coerceIn(0, sortNames.lastIndex))
        }
        val themeNames = listOf(
            "Классический", "iOS Light", "iOS Dark", "AMOLED Black",
            "Liquid Glass", "HyperOS Mono", "OriginOS",
            "HiOS", "XOS", "iOS 26 Glass", "HyperOS 2"
        )
        val themePick = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, themeNames)
            setSelection(prefs.getInt("theme", 1).coerceIn(0, themeNames.lastIndex))
        }
        val icon = SeekBar(this).apply { max = 40; progress = prefs.getInt("icon", 56) - 40 }
        val labels = CheckBox(this).apply { text = "Показывать подписи"; isChecked = prefs.getBoolean("labels", true) }
        val dim = SeekBar(this).apply { max = 180; progress = prefs.getInt("dim", 0) }
        val glassBar = SeekBar(this).apply { max = 120; progress = prefs.getInt("glass", 45) }
        val realmeCb = CheckBox(this).apply {
            text = "Стиль «стекло» как в Realme UI (часы, иконки)"
            isChecked = prefs.getBoolean("realme", false)
        }
        val lightCb = CheckBox(this).apply {
            text = "Светлые часы на рабочем столе"
            isChecked = prefs.getBoolean("hclock_light", false)
        }
        val openAnim = CheckBox(this).apply { text = "Анимация открытия приложений"; isChecked = prefs.getBoolean("open_anim", true) }
        val borders = listOf("Без рамки", "Подсветка", "Тень")
        val bs = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, borders)
            setSelection(prefs.getInt("ib_style", 1).coerceIn(0, 2))
        }
        val bw = SeekBar(this).apply { max = 8; progress = prefs.getInt("ib_width", 3) }
        val bi = SeekBar(this).apply { max = 100; progress = prefs.getInt("ib_int", 100) }
        val ba = SeekBar(this).apply { max = 360; progress = prefs.getInt("ib_angle", 90) }
        val br = SeekBar(this).apply { max = 50; progress = prefs.getInt("ic_round", 30) - 10 }
        val tw = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Ширина экрана лаунчера, dp (пусто = как в системе)"
            val cur = prefs.getInt("target_w", 0)
            if (cur > 0) setText(cur.toString())
        }
        val wblur = CheckBox(this).apply { text = "Размытие фона при открытии списка (Android 12+)"; isChecked = prefs.getBoolean("wblur", true) }
        val wp = Button(this).apply { text = "Обои"; setOnClickListener { wallpaperDialog() } }
        val unhide = Button(this).apply {
            text = "Показать скрытые приложения"
            setOnClickListener { prefs.edit().remove("hidden").apply(); applyFilter(); toast("Готово") }
        }
        box.addView(label("Готовая тема оформления")); box.addView(themePick)
        box.addView(Button(this).apply {
            text = "Открыть отдельное приложение iOS Themes"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.example.homethemes")
                if (launch != null) startActivity(launch) else toast("Сначала установите APK iOS Themes")
            }
        })
        box.addView(label("Колонок в списке приложений")); box.addView(cols)
        box.addView(label("Сетка рабочего стола — колонок")); box.addView(homeColsPick)
        box.addView(label("Сетка рабочего стола — строк")); box.addView(homeRowsPick)
        box.addView(label("Количество мест в док-панели")); box.addView(dockSlotsPick)
        box.addView(label("Размер подписей иконок")); box.addView(labelSize)
        box.addView(label("Прозрачность док-панели")); box.addView(dockAlpha)
        box.addView(label("Сортировка приложений")); box.addView(sortPick)
        box.addView(label("Размер иконок")); box.addView(icon)
        box.addView(labels)
        box.addView(realmeCb); box.addView(lightCb)
        box.addView(label("Затемнение фона")); box.addView(dim)
        box.addView(label("Яркость стекла (панели, док, поиск)")); box.addView(glassBar)
        box.addView(wblur)
        box.addView(openAnim)
        box.addView(label("Рамка иконок (стиль Realme)")); box.addView(bs)
        box.addView(label("Толщина рамки")); box.addView(bw)
        box.addView(label("Интенсивность рамки")); box.addView(bi)
        box.addView(label("Угол подсветки")); box.addView(ba)
        box.addView(label("Скругление иконок")); box.addView(br)
        box.addView(label("Масштаб интерфейса лаунчера (наименьшая ширина, dp)")); box.addView(tw)
        box.addView(label(if (glassBmp == null) "Для размытия под стеклом задайте обои через «Обои»" else "Стекло подстроено под ваши обои"))
        val lockCb = CheckBox(this).apply {
            text = "Свой экран блокировки (поверх системного)"
            isChecked = prefs.getBoolean("lock", false)
        }
        val lockTest = Button(this).apply {
            text = "Посмотреть экран блокировки"
            setOnClickListener { startActivity(Intent(this@MainActivity, LockActivity::class.java)) }
        }
        val battery = Button(this).apply {
            text = "Не ограничивать батарею"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (e: Throwable) { toast("Откройте настройки батареи вручную") }
            }
        }
        box.addView(wp)
        box.addView(Button(this).apply { text = "Живые обои"; setOnClickListener { liveDialog() } })
        box.addView(Button(this).apply { text = "Вырез экрана (Waterfall и др.)"; setOnClickListener { cutoutDialog() } })
        box.addView(unhide)
        box.addView(label("Экран блокировки")); box.addView(lockCb)
        box.addView(Button(this).apply { text = "Настроить стиль экрана блокировки"; setOnClickListener { lockStyleDialog() } })
        box.addView(lockTest); box.addView(battery)
        AlertDialog.Builder(this).setTitle("Настройки").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Готово") { _, _ ->
                val oldHomeCols = prefs.getInt("home_cols", 4)
                val oldHomeRows = prefs.getInt("home_rows", 6)
                prefs.edit()
                    .putInt("theme", themePick.selectedItemPosition)
                    .putInt("cols", colsOpts[cols.selectedItemPosition])
                    .putInt("home_cols", homeColsOpts[homeColsPick.selectedItemPosition])
                    .putInt("home_rows", homeRowsOpts[homeRowsPick.selectedItemPosition])
                    .putInt("dock_slots", dockSlotsOpts[dockSlotsPick.selectedItemPosition])
                    .putInt("label_size", labelSize.progress + 10)
                    .putInt("dock_alpha", dockAlpha.progress)
                    .putInt("app_sort", sortPick.selectedItemPosition)
                    .putInt("icon", icon.progress + 40)
                    .putBoolean("labels", labels.isChecked)
                    .putInt("dim", dim.progress)
                    .putInt("glass", glassBar.progress)
                    .putBoolean("wblur", wblur.isChecked)
                    .putBoolean("realme", realmeCb.isChecked)
                    .putBoolean("open_anim", openAnim.isChecked)
                    .putInt("ib_style", bs.selectedItemPosition)
                    .putInt("ib_width", bw.progress)
                    .putInt("ib_int", bi.progress)
                    .putInt("ib_angle", ba.progress)
                    .putInt("ic_round", br.progress + 10)
                    .putBoolean("hclock_light", lightCb.isChecked).apply()
                val newW = tw.text.toString().toIntOrNull() ?: 0
                val oldW = prefs.getInt("target_w", 0)
                val selectedHomeCols = homeColsOpts[homeColsPick.selectedItemPosition]
                val selectedHomeRows = homeRowsOpts[homeRowsPick.selectedItemPosition]
                prefs.edit().putInt("target_w", if (newW in 300..600) newW else 0).apply()
                normalizeHomeItems()
                applySettings()
                if ((if (newW in 300..600) newW else 0) != oldW || oldHomeCols != selectedHomeCols || oldHomeRows != selectedHomeRows) recreate()
                val on = lockCb.isChecked
                prefs.edit().putBoolean("lock", on).apply()
                if (on) {
                    if (!Settings.canDrawOverlays(this)) {
                        toast("Разрешите «Поверх других приложений» для Home Launcher")
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    } else {
                        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 5)
                        startLock(true)
                    }
                } else startLock(false)
            }
            .setNegativeButton("Отмена", null).show()
    }

    /** Редактор часов «как на iPhone» с живым предпросмотром. */
    private fun clockEditor() {
        val cfg = LiquidCfg.load(prefs)
        val preview = LiquidClockView(this, cfg, null)
        val pv = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#22304A"), Color.parseColor("#7A4E86"))
            )
        }
        pv.addView(preview, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)).apply {
            setMargins(dp(24), dp(8), dp(24), dp(8))
        })

        fun update() {
            val lp = preview.layoutParams
            lp.height = dp((if (cfg.stacked) 300 else 190) * cfg.heightPct / 100)
            preview.layoutParams = lp
            preview.invalidate()
        }
        fun label(t: String) = TextView(this@MainActivity).apply { text = t; setPadding(0, dp(12), 0, dp(2)) }
        fun bar(max: Int, v: Int, f: (Int) -> Unit) = SeekBar(this@MainActivity).apply {
            this.max = max
            progress = v
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { f(p); update() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        fun spin(items: List<String>, sel: Int, f: (Int) -> Unit) = Spinner(this@MainActivity).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel.coerceIn(0, items.size - 1))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { f(pos); update() }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        fun check(t: String, v: Boolean, f: (Boolean) -> Unit) = CheckBox(this@MainActivity).apply {
            text = t; isChecked = v
            setOnCheckedChangeListener { _, on -> f(on); update() }
        }

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), 0) }
        box.addView(label("Шрифт"))
        box.addView(spin(LC_FONTS, cfg.font) { cfg.font = it })
        box.addView(label("Цвет стекла"))
        box.addView(spin(LC_COLORS.map { it.first }, LC_COLORS.indexOfFirst { it.second == cfg.color }.coerceAtLeast(0)) {
            cfg.color = LC_COLORS[it].second
        })
        box.addView(check("Цифры столбиком (часы над минутами)", cfg.stacked) { cfg.stacked = it })
        box.addView(check("Показывать дату", cfg.date) { cfg.date = it })
        box.addView(check("24-часовой формат", cfg.h24) { cfg.h24 = it })
        box.addView(label("Яркость стекла"))
        box.addView(bar(140, cfg.glass) { cfg.glass = it })
        box.addView(label("Толщина ободка"))
        box.addView(bar(12, cfg.rim) { cfg.rim = it })
        box.addView(label("Высота цифр"))
        box.addView(bar(80, cfg.heightPct - 60) { cfg.heightPct = it + 60 })
        box.addView(label("Ширина цифр"))
        box.addView(bar(50, cfg.widthPct - 50) { cfg.widthPct = it + 50 })
        box.addView(label("Отступ сверху"))
        box.addView(bar(320, cfg.top) { cfg.top = it })
        update()

        val rootBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rootBox.addView(pv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250)))
        rootBox.addView(ScrollView(this).apply { addView(box) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250)))

        val save = {
            LiquidCfg.save(prefs, cfg)
            prefs.edit().putInt("lk_style", 5).apply()
        }
        AlertDialog.Builder(this).setTitle("Часы как на iPhone").setView(rootBox)
            .setPositiveButton("Сохранить") { _, _ -> save(); toast("Сохранено") }
            .setNeutralButton("Сохранить и посмотреть") { _, _ ->
                save(); startActivity(Intent(this, LockActivity::class.java))
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun lockStyleDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        fun label(t: String) = TextView(this@MainActivity).apply { text = t; setPadding(0, dp(14), 0, dp(2)) }
        val styles = listOf("Стеклянная карточка", "Крупные часы без панели", "Компактная плашка", "Realme: цифры в ряд", "Realme: цифры столбиком", "Как на iPhone (стекло)")
        val st = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, styles)
            setSelection(prefs.getInt("lk_style", 0).coerceIn(0, 5))
        }
        val alpha = SeekBar(this).apply { max = 140; progress = prefs.getInt("lk_alpha", 50) }
        val colors = listOf(
            "Белый" to Color.WHITE, "Чёрный" to Color.parseColor("#111111"), "Тёплый" to Color.parseColor("#FFD9A8"),
            "Голубой" to Color.parseColor("#A8E6FF"), "Розовый" to Color.parseColor("#FFC1E3")
        )
        val cs = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, colors.map { it.first })
            setSelection(colors.indexOfFirst { it.second == prefs.getInt("lk_color", Color.WHITE) }.coerceAtLeast(0))
        }
        val size = SeekBar(this).apply { max = 80; progress = prefs.getInt("lk_size", 80) - 40 }
        val dim = SeekBar(this).apply { max = 160; progress = prefs.getInt("lk_dim", 60) }
        val cbDate = CheckBox(this).apply { text = "Показывать дату"; isChecked = prefs.getBoolean("lk_date", true) }
        val cb24 = CheckBox(this).apply { text = "24-часовой формат"; isChecked = prefs.getBoolean("lk_24", true) }
        val cbBatt = CheckBox(this).apply { text = "Показывать заряд батареи"; isChecked = prefs.getBoolean("lk_batt", true) }
        val cbHint = CheckBox(this).apply { text = "Подсказка «Проведите вверх»"; isChecked = prefs.getBoolean("lk_hint", true) }
        box.addView(Button(this).apply {
            text = "Редактор часов как на iPhone"
            setOnClickListener { clockEditor() }
        })
        box.addView(label("Стиль часов")); box.addView(st)
        box.addView(label("Яркость стекла")); box.addView(alpha)
        box.addView(label("Цвет текста")); box.addView(cs)
        box.addView(label("Размер часов")); box.addView(size)
        box.addView(label("Затемнение обоев")); box.addView(dim)
        box.addView(cbDate); box.addView(cb24); box.addView(cbBatt); box.addView(cbHint)
        val modes = listOf("После пробуждения телефона (совместимо с AOD)", "Сразу при выключении экрана (может мешать AOD)")
        val ms = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, modes)
            setSelection(prefs.getInt("lk_mode", 0).coerceIn(0, 1))
        }
        box.addView(label("Когда показывать экран блокировки")); box.addView(ms)
        box.addView(label(if (File(filesDir, "lockglass.jpg").exists()) "Размытие под стеклом: активно"
            else "Для размытия задайте обои: Обои → Экран блокировки"))
        val save = {
            prefs.edit()
                .putInt("lk_style", st.selectedItemPosition)
                .putInt("lk_alpha", alpha.progress)
                .putInt("lk_color", colors[cs.selectedItemPosition].second)
                .putInt("lk_size", size.progress + 40)
                .putInt("lk_dim", dim.progress)
                .putBoolean("lk_date", cbDate.isChecked)
                .putBoolean("lk_24", cb24.isChecked)
                .putBoolean("lk_batt", cbBatt.isChecked)
                .putBoolean("lk_hint", cbHint.isChecked)
                .putInt("lk_mode", ms.selectedItemPosition).apply()
        }
        AlertDialog.Builder(this).setTitle("Экран блокировки").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Сохранить") { _, _ -> save() }
            .setNeutralButton("Сохранить и посмотреть") { _, _ ->
                save(); startActivity(Intent(this, LockActivity::class.java))
            }
            .setNegativeButton("Отмена", null).show()
    }

    // ================= вырез экрана (через Shizuku) =================

    private val cutoutNames = listOf(
        "Вариант по умолчанию", "Вырез на экране Waterfall", "Сверху и снизу", "Вырез Punch Hole",
        "Сверху (узкий)", "Сверху (широкий)", "Сверху (высокий)", "В правом углу"
    )
    private val cutoutIds = listOf("", "waterfall", "double", "hole", "narrow", "wide", "tall", "corner")

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { toast("Доступ Shizuku: " + if (shizukuOk()) "выдан" else "отказано") }
    }

    private fun shizukuOk() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) toast("Shizuku не запущен. Откройте Shizuku и нажмите Start")
            else Shizuku.requestPermission(0)
        } catch (e: Throwable) { toast("Shizuku не установлен") }
    }

    private fun shizukuSh(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }

    private fun applyCutout(i: Int) {
        if (!shizukuOk()) { toast("Нужен доступ Shizuku: запустите Shizuku и нажмите «Доступ Shizuku»"); return }
        val base = "com.android.internal.display.cutout.emulation"
        val all = listOf("corner", "double", "narrow", "wide", "tall", "hole", "waterfall")
        val off = all.joinToString("; ") { "cmd overlay disable $base.$it" }
        val cmd = if (cutoutIds[i].isEmpty()) off else "$off; cmd overlay enable $base.${cutoutIds[i]}"
        thread {
            val r = try { shizukuSh(cmd) } catch (e: Throwable) { "Ошибка: ${e.message}" }
            runOnUiThread {
                prefs.edit().putInt("cutout", i).apply()
                toast(if (r.isEmpty()) "Вырез: ${cutoutNames[i]}" else r.take(160))
            }
        }
    }

    private fun cutoutDialog() {
        AlertDialog.Builder(this).setTitle("Вырез на экране")
            .setSingleChoiceItems(cutoutNames.toTypedArray(), prefs.getInt("cutout", 0)) { d, i ->
                d.dismiss(); applyCutout(i)
            }
            .setNeutralButton("Доступ Shizuku") { _, _ -> requestShizuku() }
            .setNegativeButton("Отмена", null).show()
    }

    // ================= живые обои =================

    private fun liveDialog() {
        val opts = arrayOf(
            "Анимация: Аврора", "Анимация: Закат", "Анимация: Океан", "Анимация: Графит",
            "Видео из галереи…", "Установить как обои"
        )
        AlertDialog.Builder(this).setTitle("Живые обои").setItems(opts) { _, i ->
            when {
                i in 0..3 -> {
                    prefs.edit().putInt("live_mode", 0).putInt("live_theme", i).apply()
                    setLive()
                }
                i == 4 -> startActivityForResult(
                    Intent.createChooser(Intent(Intent.ACTION_GET_CONTENT).setType("video/*"), "Видео"), 78
                )
                else -> setLive()
            }
        }.show()
    }

    private fun setLive() {
        val comp = ComponentName(this, LiveWallpaperService::class.java)
        try {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, comp)
            )
        } catch (e: Throwable) {
            try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
            catch (e2: Throwable) { toast("Откройте Настройки → Обои → Живые обои") }
        }
    }

    private fun cropToScreen(src: Bitmap): Bitmap {
        val dm = resources.displayMetrics
        val tw = dm.widthPixels
        val th = dm.heightPixels
        val scale = maxOf(tw.toFloat() / src.width, th.toFloat() / src.height)
        val nw = maxOf(tw, ceil(src.width * scale).toInt())
        val nh = maxOf(th, ceil(src.height * scale).toInt())
        val scaled = Bitmap.createScaledBitmap(src, nw, nh, true)
        return Bitmap.createBitmap(scaled, (nw - tw) / 2, (nh - th) / 2, tw, th)
    }

    private fun wallpaperDialog() {
        AlertDialog.Builder(this).setTitle("Куда поставить обои")
            .setItems(arrayOf("Домашний экран", "Экран блокировки", "Оба экрана", "Живые обои…")) { _, i ->
                if (i == 3) { liveDialog(); return@setItems }
                wallTarget = i
                startActivityForResult(Intent.createChooser(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), "Обои"), 77)
            }.show()
    }

    private fun decode(uri: Uri): Bitmap {
        val dm = resources.displayMetrics
        val tw = dm.widthPixels
        val th = dm.heightPixels
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= tw && o.outHeight / (s * 2) >= th) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val src = contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) }!!
        val scale = maxOf(tw.toFloat() / src.width, th.toFloat() / src.height)
        val nw = maxOf(tw, ceil(src.width * scale).toInt())
        val nh = maxOf(th, ceil(src.height * scale).toInt())
        val scaled = Bitmap.createScaledBitmap(src, nw, nh, true)
        return Bitmap.createBitmap(scaled, (nw - tw) / 2, (nh - th) / 2, tw, th)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 88) { if (res == RESULT_OK) afterBind(pendingId) else host.deleteAppWidgetId(pendingId); return }
        if (req == 89) { if (res == RESULT_OK) addWidget(pendingId) else host.deleteAppWidgetId(pendingId); return }
        if (req == 78 && res == RESULT_OK) {
            val uri = data?.data ?: return
            toast("Загружаю видео…")
            thread {
                try {
                    val out = File(filesDir, "live.mp4")
                    contentResolver.openInputStream(uri)!!.use { inp -> out.outputStream().use { inp.copyTo(it) } }
                    prefs.edit().putInt("live_mode", 1).apply()
                    // кадр из видео — для размытия под стеклом и фона своего экрана блокировки
                    val mmr = MediaMetadataRetriever()
                    mmr.setDataSource(out.path)
                    val fr = mmr.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    mmr.release()
                    if (fr != null) {
                        val bmp = cropToScreen(fr)
                        saveGlass(bmp)
                        saveGlass(bmp, "lockglass.jpg")
                        saveJpeg(bmp, "lockbg.jpg")
                    }
                    runOnUiThread { loadGlass(); applyGlass(); setLive() }
                } catch (e: Throwable) {
                    runOnUiThread { toast("Ошибка: ${e.message}") }
                }
            }
            return
        }
        if (req == 77 && res == RESULT_OK) {
            val uri = data?.data ?: return
            toast("Устанавливаю обои…")
            thread {
                try {
                    val flags = when (wallTarget) {
                        0 -> WallpaperManager.FLAG_SYSTEM
                        1 -> WallpaperManager.FLAG_LOCK
                        else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                    }
                    val bmp = decode(uri)
                    WallpaperManager.getInstance(this).setBitmap(bmp, null, true, flags)
                    if (wallTarget != 1) saveGlass(bmp)
                    if (wallTarget != 0) { saveJpeg(bmp, "lockbg.jpg"); saveGlass(bmp, "lockglass.jpg") }
                    runOnUiThread { loadGlass(); applyGlass(); toast("Обои установлены") }
                } catch (e: Throwable) {
                    runOnUiThread { toast("Ошибка: ${e.message}") }
                }
            }
        }
    }

    // ================= список всех приложений =================

    inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val a = shown[i]
            val v2 = iconView(a, {}, {})
            v2.setOnClickListener(null); v2.setOnLongClickListener(null)
            v2.isClickable = false; v2.isLongClickable = false
            v2.setPadding(dp(4), dp(10), dp(4), dp(10))
            return v2
        }
    }

    // ================= создание =================

    private fun applyThemeIntent(intent: Intent?) {
        if (intent?.action != "com.example.homelauncher.action.APPLY_THEME") return
        val theme = intent.getIntExtra("theme_index", -1)
        if (theme !in 0..10) return
        val edit = prefs.edit().putInt("theme", theme).putBoolean("realme", false)
        if (intent.hasExtra("home_cols")) edit.putInt("home_cols", intent.getIntExtra("home_cols", 4).coerceIn(3, 6))
        if (intent.hasExtra("home_rows")) edit.putInt("home_rows", intent.getIntExtra("home_rows", 6).coerceIn(4, 8))
        if (intent.hasExtra("icon_size")) edit.putInt("icon", intent.getIntExtra("icon_size", 56).coerceIn(40, 80))
        if (intent.hasExtra("dim")) edit.putInt("dim", intent.getIntExtra("dim", 0).coerceIn(0, 180))
        if (intent.hasExtra("glass")) edit.putInt("glass", intent.getIntExtra("glass", 45).coerceIn(0, 120))
        if (intent.hasExtra("ic_round")) edit.putInt("ic_round", intent.getIntExtra("ic_round", 30).coerceIn(10, 60))
        if (intent.hasExtra("label_size")) edit.putInt("label_size", intent.getIntExtra("label_size", 12).coerceIn(10, 18))
        if (intent.hasExtra("dock_alpha")) edit.putInt("dock_alpha", intent.getIntExtra("dock_alpha", 62).coerceIn(0, 100))
        if (intent.hasExtra("dock_slots")) edit.putInt("dock_slots", intent.getIntExtra("dock_slots", 4).coerceIn(3, 6))
        edit.apply()
        if (::root.isInitialized) {
            normalizeHomeItems()
            applySettings()
            toast("Тема применена")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("home", MODE_PRIVATE)
        awm = AppWidgetManager.getInstance(this)
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (e: Throwable) { }
        host = AppWidgetHost(this, 1024)
        pageCount = prefs.getInt("pages", 2)
        loadItems()

        root = FrameLayout(this)
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(0, ins.systemWindowInsetTop, 0, ins.systemWindowInsetBottom)
            ins
        }

        // --- главный экран ---
        val home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clockHolder = FrameLayout(this)
        home.addView(clockHolder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        pager = ViewPager(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            setPadding(dp(8), dp(8), dp(8), 0)
            clipToPadding = false
            addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
                override fun onPageSelected(position: Int) { updateDots() }
            })
        }
        pager.adapter = PagesAdapter()
        home.addView(pager)

        askPill = TextView(this).apply {
            text = "✦  Искать приложения"
            textSize = 14f; setTextColor(Color.parseColor("#33333A")); gravity = Gravity.CENTER
            setPadding(dp(22), dp(10), dp(22), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(Color.argb(170, 255, 255, 255)); setStroke(2, Color.argb(200, 255, 255, 255))
            }
            visibility = View.GONE
            setOnClickListener { openDrawer() }
        }
        home.addView(askPill, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(4) })

        dots = TextView(this).apply {
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 10f
            setShadowLayer(4f, 0f, 1f, Color.BLACK)
            setPadding(0, dp(6), 0, dp(6))
        }
        home.addView(dots)

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(Color.argb(90, 0, 0, 0)) }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(12), dp(0), dp(12), dp(12)) }
        }
        home.addView(dock)
        root.addView(home, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // --- список всех приложений (поверх) ---
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(225, 0, 0, 0))
            visibility = View.GONE
            isClickable = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(4))
        }
        search = EditText(this).apply {
            hint = "Название или пакет приложения"
            setHintTextColor(Color.argb(160, 255, 255, 255))
            setTextColor(Color.WHITE); textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT; setSingleLine()
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(Color.argb(90, 255, 255, 255)) }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { applyFilter() }
            })
        }
        bar.addView(search)
        bar.addView(TextView(this).apply {
            text = "⚙"; textSize = 26f; setTextColor(Color.WHITE)
            setPadding(dp(14), 0, dp(6), 0)
            setOnClickListener { settingsDialog() }
        })
        drawer.addView(bar)

        adapter = AppAdapter()
        grid = GridView(this).apply {
            numColumns = prefs.getInt("cols", 4)
            adapter = this@MainActivity.adapter
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            clipToPadding = false
            selector = ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, i, _ -> launch(shown[i].pkg); closeDrawer() }
            setOnItemLongClickListener { _, _, i, _ -> appMenu(shown[i]); true }
        }
        drawer.addView(grid)
        root.addView(drawer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        editBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(dp(8), dp(12), dp(8), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                setColor(Color.argb(200, 24, 24, 28))
                setStroke(2, Color.argb(90, 255, 255, 255))
            }
        }
        fun editItem(sym: String, name: String, f: () -> Unit) {
            val t = TextView(this).apply {
                text = "$sym\n$name"; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { f() }
            }
            editBar.addView(t)
        }
        editItem("🖼", "Обои") { wallpaperDialog() }
        editItem("▤", "Виджеты") { pickWidget() }
        editItem("⧉", "Страницы") { pagesDialog() }
        editItem("⚙", "Настройки") { settingsDialog() }
        editItem("✔", "Готово") { editBar.visibility = View.GONE }
        root.addView(editBar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        ).apply { setMargins(dp(12), 0, dp(12), dp(16)) })

        setContentView(root)
        loadGlass()
        applySettings()
        applyThemeIntent(intent)
        if (prefs.getBoolean("lock", false) && Settings.canDrawOverlays(this)) startLock(true)
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (e: Throwable) { }
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        try { host.startListening() } catch (e: Throwable) { }
    }

    override fun onStop() {
        try { host.stopListening() } catch (e: Throwable) { }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyThemeIntent(intent)
        closeDrawer()
        moving = null
        if (resizing != null) { resizing = null; refreshHome() }
        pager.currentItem = 0
        applySettings()
    }

    override fun onBackPressed() {
        when {
            drawer.visibility == View.VISIBLE -> closeDrawer()
            editBar.visibility == View.VISIBLE -> editBar.visibility = View.GONE
            moving != null -> { moving = null; toast("Перемещение отменено") }
            resizing != null -> { resizing = null; refreshHome() }
        }
    }
}
