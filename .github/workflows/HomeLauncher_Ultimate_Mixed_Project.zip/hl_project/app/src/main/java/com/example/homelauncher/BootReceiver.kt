package com.example.homelauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED &&
            c.getSharedPreferences("home", Context.MODE_PRIVATE).getBoolean("lock", false) &&
            Settings.canDrawOverlays(c)
        ) {
            try { c.startForegroundService(Intent(c, LockService::class.java)) } catch (e: Throwable) { }
        }
    }
}
