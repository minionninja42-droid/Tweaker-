package com.example.homelauncher

import android.app.Activity
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.MediaStore
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import java.io.File

/** Свой экран блокировки в стиле «стекло». Настройки берутся из SharedPreferences "home" (ключи lk_*). */
class LockActivity : Activity() {

    private var downY = 0f
    private lateinit var root: FrameLayout

    private val unlocked = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { finish() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun loadBmp(name: String): Bitmap? {
        val f = File(filesDir, name)
        return try { if (f.exists()) BitmapFactory.decodeFile(f.path) else null } catch (e: Throwable) { null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val f = IntentFilter(Intent.ACTION_USER_PRESENT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(unlocked, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(unlocked, f)

        // ---- настройки оформления ----
        val sp = getSharedPreferences("home", MODE_PRIVATE)
        val style = sp.getInt("lk_style", 0)
        val glassA = sp.getInt("lk_alpha", 50)
        val textColor = sp.getInt("lk_color", Color.WHITE)
        val timeSize = sp.getInt("lk_size", 80).toFloat()
        val showDate = sp.getBoolean("lk_date", true)
        val h24 = sp.getBoolean("lk_24", true)
        val showHint = sp.getBoolean("lk_hint", true)
        val showBatt = sp.getBoolean("lk_batt", true)
        val dim = sp.getInt("lk_dim", 60)
        val tint = Color.argb(glassA, 255, 255, 255)
        val lockGlass = loadBmp("lockglass.jpg")
        val shadow = if (textColor == Color.WHITE || Color.luminance(textColor) > 0.5f) Color.argb(110, 0, 0, 0) else Color.TRANSPARENT

        fun glass(v: View, radiusDp: Int) {
            v.background = GlassDrawable(v, dp(radiusDp).toFloat(), lockGlass, tint)
        }

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        root = FrameLayout(this)

        // ---- фон ----
        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val bmp = loadBmp("lockbg.jpg")
        if (bmp != null) bg.setImageBitmap(bmp) else bg.setBackgroundColor(Color.parseColor("#101018"))
        root.addView(bg, FrameLayout.LayoutParams(match, match))
        root.addView(View(this).apply { setBackgroundColor(Color.argb(dim, 0, 0, 0)) },
            FrameLayout.LayoutParams(match, match))

        // ---- часы и дата ----
        fun time(sizeSp: Float) = TextClock(this).apply {
            val fmt = if (h24) "HH:mm" else "h:mm"
            format24Hour = fmt; format12Hour = fmt
            textSize = sizeSp; setTextColor(textColor)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setShadowLayer(8f, 0f, 2f, shadow)
        }
        fun date(sizeSp: Float) = TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"; format12Hour = "EEEE, d MMMM"
            textSize = sizeSp; setTextColor(textColor)
            setShadowLayer(6f, 0f, 1f, shadow)
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(96), 0, 0)
        }

        when (style) {
            0 -> { // стеклянная карточка
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(28), dp(22), dp(28), dp(22))
                }
                card.addView(time(timeSize))
                if (showDate) card.addView(date(18f))
                glass(card, 32)
                col.addView(card, LinearLayout.LayoutParams(match, wrap).apply { setMargins(dp(28), 0, dp(28), 0) })
            }
            1 -> { // крупные часы без панели
                col.addView(time(timeSize))
                if (showDate) col.addView(date(18f))
            }
            5 -> { // как на iPhone (iOS 26): огромные вытянутые цифры из жидкого стекла
                val cfg = LiquidCfg.load(sp)
                col.setPadding(0, dp(cfg.top), 0, 0)
                val baseH = if (cfg.stacked) 430 else 290
                col.addView(LiquidClockView(this, cfg, lockGlass), LinearLayout.LayoutParams(
                    resources.displayMetrics.widthPixels - dp(32), dp(baseH * cfg.heightPct / 100)
                ))
            }
            3, 4 -> { // как в Realme UI: цифры-стекло в рамке
                val stacked = style == 4
                val gv = GlassClockView(this, stacked, true, h24, true, showDate)
                val w = if (stacked) dp(210) else resources.displayMetrics.widthPixels - dp(56)
                val h = if (stacked) dp(330) else dp(190)
                col.addView(gv, LinearLayout.LayoutParams(w, h))
            }
            else -> { // компактная плашка
                val pill = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(22), dp(10), dp(22), dp(10))
                }
                pill.addView(time(30f))
                if (showDate) {
                    pill.addView(TextView(this).apply { text = "   "; textSize = 14f })
                    pill.addView(date(15f))
                }
                glass(pill, 28)
                col.addView(pill, LinearLayout.LayoutParams(wrap, wrap))
            }
        }

        if (showBatt) {
            val pct = try {
                getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            } catch (e: Throwable) { -1 }
            if (pct >= 0) {
                val b = TextView(this).apply {
                    text = "🔋 $pct%"; textSize = 15f; setTextColor(textColor); gravity = Gravity.CENTER
                    setPadding(dp(20), dp(8), dp(20), dp(8))
                }
                glass(b, 22)
                col.addView(b, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(18) })
            }
        }
        root.addView(col, FrameLayout.LayoutParams(match, match))

        // ---- подсказка внизу ----
        if (showHint && style != 5) {
            val hint = TextView(this).apply {
                text = "⌃   Проведите вверх"
                textSize = 15f; setTextColor(textColor); gravity = Gravity.CENTER
                setPadding(dp(28), dp(14), dp(28), dp(14))
            }
            glass(hint, 28)
            root.addView(hint, FrameLayout.LayoutParams(wrap, wrap, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = dp(64) })
        }

        if (style == 5) {
            // фонарик слева, камера справа, полоска «домой» внизу — как на iPhone
            var torchOn = false
            val torch = TextView(this).apply {
                text = "🔦"; textSize = 20f; gravity = Gravity.CENTER; alpha = 0.85f
                setOnClickListener {
                    try {
                        val cm = getSystemService(CameraManager::class.java)
                        val id = cm.cameraIdList.first {
                            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        torchOn = !torchOn
                        cm.setTorchMode(id, torchOn)
                        alpha = if (torchOn) 1f else 0.85f
                        scaleX = if (torchOn) 1.12f else 1f
                        scaleY = scaleX
                    } catch (e: Throwable) { }
                }
            }
            glass(torch, 28)
            root.addView(torch, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.START)
                .apply { leftMargin = dp(28); bottomMargin = dp(56) })

            val cam = TextView(this).apply {
                text = "📷"; textSize = 20f; gravity = Gravity.CENTER; alpha = 0.85f
                setOnClickListener {
                    try {
                        startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Throwable) {
                        try {
                            startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e2: Throwable) { }
                    }
                }
            }
            glass(cam, 28)
            root.addView(cam, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END)
                .apply { rightMargin = dp(28); bottomMargin = dp(56) })

            root.addView(View(this).apply {
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(3).toFloat(); setColor(Color.argb(225, 255, 255, 255))
                }
            }, FrameLayout.LayoutParams(dp(134), dp(5), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = dp(14) })
        }

        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> downY = e.rawY
                MotionEvent.ACTION_MOVE -> {
                    val pr = ((downY - e.rawY) / dp(320)).coerceIn(0f, 1f)
                    root.translationY = minOf(0f, e.rawY - downY) * 0.6f
                    root.alpha = 1f - 0.7f * pr
                    root.scaleX = 1f - 0.08f * pr
                    root.scaleY = 1f - 0.08f * pr
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    if (downY - e.rawY > dp(140)) dismiss()
                    else root.animate().translationY(0f).alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
            }
            true
        }
        setContentView(root)
    }

    private fun dismiss() {
        val km = getSystemService(KeyguardManager::class.java)
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
            override fun onDismissCancelled() { root.animate().translationY(0f).alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start() }
            override fun onDismissError() { finish() }
        })
    }

    override fun onBackPressed() { /* назад на экране блокировки не работает */ }

    override fun onDestroy() {
        try { unregisterReceiver(unlocked) } catch (e: Throwable) { }
        super.onDestroy()
    }
}
