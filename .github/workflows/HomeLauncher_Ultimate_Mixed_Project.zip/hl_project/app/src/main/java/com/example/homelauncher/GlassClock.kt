package com.example.homelauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Крупные узкие цифры с «стеклянным» градиентом (сверху плотно, вниз растворяются), как в Realme UI.
 * framed = true: цифры в тонкой рамке с дугой в углу и маленькой датой (экран блокировки).
 * stacked = true: часы и минуты в два этажа.
 */
class GlassClockView(
    ctx: Context,
    private val stacked: Boolean,
    private val framed: Boolean,
    private val h24: Boolean,
    private val light: Boolean,
    private val showDate: Boolean = true
) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = Rect()
    private val tick = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 1000) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }

    private fun fit(c: Canvas, text: String, left: Float, top: Float, w: Float, h: Float, maxSy: Float) {
        p.textSize = 100f
        p.getTextBounds(text, 0, text.length, r)
        if (r.width() <= 0 || r.height() <= 0) return
        val k = w / r.width()
        val sy = minOf(h / (r.height() * k), maxSy)
        val topCol = if (light) Color.argb(240, 255, 255, 255) else Color.argb(240, 60, 60, 64)
        val botCol = if (light) Color.argb(40, 255, 255, 255) else Color.argb(25, 60, 60, 64)
        p.shader = LinearGradient(0f, r.top.toFloat(), 0f, r.bottom.toFloat(), topCol, botCol, Shader.TileMode.CLAMP)
        c.save()
        c.translate(left, top + (h - r.height() * k * sy) / 2f)
        c.scale(k, k * sy)
        c.drawText(text, -r.left.toFloat(), -r.top.toFloat(), p)
        c.restore()
        p.shader = null
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cal = Calendar.getInstance()
        var h = cal.get(if (h24) Calendar.HOUR_OF_DAY else Calendar.HOUR)
        if (!h24 && h == 0) h = 12
        val mm = "%02d".format(cal.get(Calendar.MINUTE))
        val hh = if (framed) "%02d".format(h) else h.toString()
        val w = width.toFloat()
        val ht = height.toFloat()

        p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        p.style = Paint.Style.FILL

        if (!framed) {
            fit(c, "$hh:$mm", 0f, 0f, w, ht, 1.6f)
            return
        }

        // рамка
        val rect = RectF(2 * d, 2 * d, w - 2 * d, ht - 2 * d)
        p.color = Color.argb(28, 255, 255, 255)
        c.drawRoundRect(rect, 16 * d, 16 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2 * d
        p.color = Color.argb(215, 255, 255, 255)
        c.drawRoundRect(rect, 16 * d, 16 * d, p)
        p.strokeWidth = 5 * d
        p.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(rect.right - 32 * d, rect.bottom - 32 * d, rect.right, rect.bottom), 0f, 90f, false, p)
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL

        val pad = 14 * d
        val topPad = if (showDate) 34 * d else pad
        if (stacked) {
            val gap = 8 * d
            val lh = (ht - topPad - pad - gap) / 2f
            fit(c, hh, pad, topPad, w - 2 * pad, lh, 2.4f)
            fit(c, mm, pad, topPad + lh + gap, w - 2 * pad, lh, 2.4f)
        } else {
            fit(c, hh + mm, pad, topPad, w - 2 * pad, ht - topPad - pad, 2.4f)
        }

        if (showDate) {
            p.typeface = Typeface.DEFAULT
            p.textSize = 12 * d
            p.color = Color.argb(225, 255, 255, 255)
            c.drawText(SimpleDateFormat("d MMM, EEE", Locale.getDefault()).format(Date()), pad, 24 * d, p)
        }
    }
}
