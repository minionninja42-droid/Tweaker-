package com.example.homelauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val LC_FONTS = listOf("Жирный", "Чёрный (ультражирный)", "Узкий", "С засечками", "Тонкий", "Моно")
val LC_COLORS = listOf(
    "Белый" to Color.WHITE,
    "Тёплый" to Color.parseColor("#FFE2B8"),
    "Голубой" to Color.parseColor("#BFE6FF"),
    "Розовый" to Color.parseColor("#FFC9E6"),
    "Зелёный" to Color.parseColor("#C6FFDD"),
    "Тёмный" to Color.parseColor("#1B1B22")
)

/** Настройки часов «жидкое стекло». Хранятся в SharedPreferences "home" (ключи lc_*). */
data class LiquidCfg(
    var font: Int = 0,
    var color: Int = Color.WHITE,
    var stacked: Boolean = false,
    var glass: Int = 50,
    var rim: Int = 4,          // толщина ободка в половинках dp
    var date: Boolean = true,
    var h24: Boolean = true,
    var heightPct: Int = 100,
    var widthPct: Int = 100,
    var top: Int = 48          // отступ сверху, dp
) {
    companion object {
        fun load(sp: SharedPreferences) = LiquidCfg(
            sp.getInt("lc_font", 0),
            sp.getInt("lc_color", Color.WHITE),
            sp.getBoolean("lc_stacked", false),
            sp.getInt("lc_glass", sp.getInt("lk_alpha", 50)),
            sp.getInt("lc_rim", 4),
            sp.getBoolean("lc_date", sp.getBoolean("lk_date", true)),
            sp.getBoolean("lc_24", sp.getBoolean("lk_24", true)),
            sp.getInt("lc_h", 100),
            sp.getInt("lc_w", 100),
            sp.getInt("lc_top", 48)
        )

        fun save(sp: SharedPreferences, c: LiquidCfg) {
            sp.edit()
                .putInt("lc_font", c.font).putInt("lc_color", c.color).putBoolean("lc_stacked", c.stacked)
                .putInt("lc_glass", c.glass).putInt("lc_rim", c.rim).putBoolean("lc_date", c.date)
                .putBoolean("lc_24", c.h24).putInt("lc_h", c.heightPct).putInt("lc_w", c.widthPct)
                .putInt("lc_top", c.top).apply()
        }
    }
}

/**
 * Часы «жидкое стекло» как на iPhone (iOS 26): огромные вытянутые цифры.
 * Внутри цифр — размытые обои (матовое стекло), блик, светлый ободок и мягкая тень снаружи.
 */
class LiquidClockView(
    ctx: Context,
    var cfg: LiquidCfg,
    private val blur: Bitmap?
) : View(ctx) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val tmp = Path()
    private val bounds = RectF()
    private val m = Matrix()
    private val loc = IntArray(2)
    private val tick = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 1000) }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }

    private fun typeface(): Typeface = when (cfg.font) {
        1 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        2 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        3 -> Typeface.create("serif", Typeface.BOLD)
        4 -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
        5 -> Typeface.create("monospace", Typeface.BOLD)
        else -> Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun textPath(s: String): RectF {
        tmp.reset()
        tp.getTextPath(s, 0, s.length, 0f, 0f, tmp)
        tmp.computeBounds(bounds, true)
        return bounds
    }

    private fun buildPath(w: Float, ht: Float, top: Float, d: Float, hour: String, min: String) {
        path.reset()
        tp.typeface = typeface()
        tp.textSize = 200f
        tp.textAlign = Paint.Align.LEFT
        val pad = 8 * d
        val maxW = w * cfg.widthPct / 100f
        if (!cfg.stacked) {
            val b = textPath("$hour:$min")
            if (b.width() <= 0f || b.height() <= 0f) return
            val sx = (maxW - 2 * pad) / b.width()
            val sy = (ht - top - pad) / b.height()
            m.reset()
            m.postTranslate(-b.left, -b.top)
            m.postScale(sx, sy)
            m.postTranslate((w - maxW) / 2f + pad, top)
            tmp.transform(m)
            path.addPath(tmp)
        } else {
            val gap = 10 * d
            val availH = (ht - top - pad - gap) / 2f
            for (line in 0..1) {
                val b = textPath(if (line == 0) hour else min)
                if (b.width() <= 0f || b.height() <= 0f) continue
                val sy = availH / b.height()
                var sx = sy * 0.62f
                if (b.width() * sx > maxW - 2 * pad) sx = (maxW - 2 * pad) / b.width()
                m.reset()
                m.postTranslate(-b.left, -b.top)
                m.postScale(sx, sy)
                m.postTranslate((w - b.width() * sx) / 2f, top + line * (availH + gap))
                tmp.transform(m)
                path.addPath(tmp)
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cal = Calendar.getInstance()
        var h = cal.get(if (cfg.h24) Calendar.HOUR_OF_DAY else Calendar.HOUR)
        if (!cfg.h24 && h == 0) h = 12
        val hourS = if (cfg.stacked && cfg.h24) "%02d".format(h) else "$h"
        val minS = "%02d".format(cal.get(Calendar.MINUTE))
        val w = width.toFloat()
        val ht = height.toFloat()
        val r = Color.red(cfg.color)
        val g = Color.green(cfg.color)
        val b = Color.blue(cfg.color)

        // дата сверху
        var top = 0f
        if (cfg.date) {
            tp.style = Paint.Style.FILL
            tp.shader = null
            tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            tp.textSize = 18 * d
            tp.textAlign = Paint.Align.CENTER
            tp.color = Color.argb(220, r, g, b)
            c.drawText(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()), w / 2f, 22 * d, tp)
            top = 34 * d
        }

        buildPath(w, ht, top, d, hourS, minS)
        if (path.isEmpty) return

        // 1) мягкая тень снаружи
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = Color.argb(80, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(10 * d, BlurMaskFilter.Blur.OUTER)
        c.drawPath(path, p)

        // 2) стекло внутри цифр
        c.save()
        c.clipPath(path)
        if (blur != null) {
            getLocationOnScreen(loc)
            val dm = resources.displayMetrics
            val kx = blur.width.toFloat() / dm.widthPixels
            val ky = blur.height.toFloat() / dm.heightPixels
            val src = Rect(
                (loc[0] * kx).toInt(), (loc[1] * ky).toInt(),
                ((loc[0] + width) * kx).toInt(), ((loc[1] + height) * ky).toInt()
            )
            c.drawBitmap(blur, src, Rect(0, 0, width, height), null)
        }
        val topA = (cfg.glass + if (blur != null) 50 else 110).coerceIn(0, 235)
        val botA = (cfg.glass / 2 + if (blur != null) 15 else 60).coerceIn(0, 200)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, top, 0f, ht, Color.argb(topA, r, g, b), Color.argb(botA, r, g, b), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, ht, p)
        // блик по диагонали
        p.shader = LinearGradient(0f, top, w * 0.85f, top + (ht - top) * 0.6f,
            Color.argb(120, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, ht, p)
        // внутреннее свечение у краёв
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 8 * d
        p.color = Color.argb(75, r, g, b)
        p.maskFilter = BlurMaskFilter(5 * d, BlurMaskFilter.Blur.NORMAL)
        c.drawPath(path, p)
        c.restore()

        // 3) ободок
        if (cfg.rim > 0) {
            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.STROKE
            p.strokeWidth = cfg.rim * 0.5f * d
            p.shader = LinearGradient(0f, top, 0f, ht, Color.argb(255, r, g, b), Color.argb(120, r, g, b), Shader.TileMode.CLAMP)
            c.drawPath(path, p)
        }
    }
}
