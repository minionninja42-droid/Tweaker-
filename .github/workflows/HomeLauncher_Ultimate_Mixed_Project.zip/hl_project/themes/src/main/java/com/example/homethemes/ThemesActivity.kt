package com.example.homethemes

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class ThemesActivity : Activity() {
    private data class Preset(
        val title: String,
        val subtitle: String,
        val themeIndex: Int,
        val colors: IntArray,
        val previewText: String,
        val homeCols: Int = 5,
        val homeRows: Int = 6,
        val iconSize: Int = 56,
        val dim: Int = 0,
        val glass: Int = 55,
        val round: Int = 30,
        val labelSize: Int = 12,
        val dockAlpha: Int = 65,
        val dockSlots: Int = 4
    )

    private val presets = listOf(
        Preset("iOS 26 · Liquid Glass", "Светлые полупрозрачные панели и мягкие блики", 9,
            intArrayOf(Color.rgb(215, 231, 255), Color.rgb(133, 166, 221), Color.rgb(238, 222, 255)), "9:41", 5, 6, 58, 0, 58, 32, 13, 68, 4),
        Preset("iOS Light", "Чистая светлая тема в стиле iPhone", 1,
            intArrayOf(Color.rgb(245, 247, 252), Color.rgb(197, 215, 244), Color.WHITE), "9:41", 5, 6, 56, 0, 48, 30, 13, 62, 4),
        Preset("iOS Dark", "Тёмные панели и контрастные элементы", 2,
            intArrayOf(Color.rgb(12, 17, 29), Color.rgb(44, 55, 78), Color.rgb(22, 25, 38)), "9:41", 5, 6, 58, 0, 45, 30, 13, 72, 4),
        Preset("AMOLED Black", "Глубокий чёрный фон для OLED-экранов", 3,
            intArrayOf(Color.BLACK, Color.rgb(25, 28, 38), Color.rgb(7, 9, 14)), "9:41", 5, 6, 56, 0, 25, 30, 12, 90, 5),
        Preset("HiOS", "Сине-графитовая палитра", 7,
            intArrayOf(Color.rgb(14, 28, 48), Color.rgb(42, 78, 112), Color.rgb(26, 43, 66)), "10:08", 5, 7, 56, 0, 38, 26, 12, 65, 5),
        Preset("XOS", "Фиолетовые акценты и плотные панели", 8,
            intArrayOf(Color.rgb(34, 23, 55), Color.rgb(91, 55, 123), Color.rgb(43, 29, 65)), "10:08", 5, 6, 56, 0, 42, 30, 12, 70, 5),
        Preset("HyperOS 2", "Холодные оттенки и аккуратная сетка", 10,
            intArrayOf(Color.rgb(20, 31, 48), Color.rgb(66, 96, 132), Color.rgb(28, 43, 65)), "10:08", 5, 6, 56, 0, 48, 28, 12, 68, 5),
        Preset("Android Classic", "Нейтральный и лёгкий интерфейс", 0,
            intArrayOf(Color.rgb(40, 49, 64), Color.rgb(85, 102, 125), Color.rgb(34, 43, 57)), "10:08", 4, 6, 52, 0, 40, 24, 12, 48, 4),
        Preset("Liquid Glass Dark", "Тёмное полупрозрачное стекло", 4,
            intArrayOf(Color.rgb(12, 16, 27), Color.rgb(65, 77, 105), Color.rgb(24, 28, 44)), "9:41", 5, 6, 58, 0, 65, 35, 13, 76, 4)
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 17, 28)
        window.navigationBarColor = Color.rgb(13, 17, 28)
        window.decorView.systemUiVisibility = 0
        setContentView(buildScreen())
    }

    private fun buildScreen(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(13, 17, 28), Color.rgb(29, 38, 60), Color.rgb(24, 25, 42)))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply {
            text = "THEMES"
            textSize = 12f; letterSpacing = .22f; setTextColor(Color.rgb(160, 174, 255))
            setTypeface(null, Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Персонализируй свой экран"
            textSize = 29f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(4))
        })
        content.addView(TextView(this).apply {
            text = "Выбери стиль и отправь его в HomeLauncher Ultimate. В каталоге есть iOS, HiOS, XOS, HyperOS и Android."
            textSize = 14f; setTextColor(Color.rgb(177, 184, 202)); setPadding(0, 0, 0, dp(18))
        })
        presets.forEach { content.addView(presetCard(it)) }
        content.addView(TextView(this).apply {
            text = "Как применить"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(6))
        })
        content.addView(TextView(this).apply {
            text = "Выбери тему и нажми «Применить тему». HomeLauncher получит пресет и обновит оформление. Для смены фотографии открой настройки лаунчера → Обои."
            textSize = 14f; setTextColor(Color.rgb(190, 202, 225)); setPadding(0, 0, 0, dp(16))
        })
        content.addView(Button(this).apply {
            text = "Открыть Home Launcher"; isAllCaps = false
            setOnClickListener { openLauncher() }
        })
        scroll.addView(content)
        page.addView(scroll)
        return page
    }

    private fun presetCard(preset: Preset): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(Color.argb(35, 255, 255, 255))
                setStroke(dp(1), Color.argb(45, 255, 255, 255))
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        }
        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, preset.colors).apply { cornerRadius = dp(18).toFloat() }
        }
        val isDark = preset.themeIndex in listOf(2, 3, 4, 5, 6, 7, 8, 10)
        preview.addView(TextView(this).apply {
            text = preset.previewText; textSize = 38f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(if (isDark) Color.WHITE else Color.rgb(35, 48, 75))
        })
        preview.addView(TextView(this).apply {
            text = "●      ●      ●      ●"; textSize = 18f
            setTextColor(if (isDark) Color.WHITE else Color.rgb(45, 65, 100)); setPadding(0, dp(8), 0, 0)
        })
        card.addView(preview, LinearLayout.LayoutParams(-1, dp(142)))
        card.addView(TextView(this).apply {
            text = preset.title; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); setPadding(0, dp(12), 0, dp(3))
        })
        card.addView(TextView(this).apply {
            text = preset.subtitle; textSize = 13f; setTextColor(Color.rgb(190, 202, 225))
        })
        card.addView(Button(this).apply {
            text = "Применить тему"; isAllCaps = false
            setOnClickListener { applyPreset(preset) }
        })
        return card
    }

    private fun applyPreset(preset: Preset) {
        val apply = Intent().apply {
            setClassName("com.example.homelauncher", "com.example.homelauncher.MainActivity")
            action = "com.example.homelauncher.action.APPLY_THEME"
            putExtra("theme_index", preset.themeIndex)
            putExtra("home_cols", preset.homeCols)
            putExtra("home_rows", preset.homeRows)
            putExtra("icon_size", preset.iconSize)
            putExtra("dim", preset.dim)
            putExtra("glass", preset.glass)
            putExtra("ic_round", preset.round)
            putExtra("label_size", preset.labelSize)
            putExtra("dock_alpha", preset.dockAlpha)
            putExtra("dock_slots", preset.dockSlots)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        try {
            startActivity(apply)
            Toast.makeText(this, "Тема «${preset.title}» применена", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Не удалось применить тему")
                .setMessage("Установи HomeLauncher Ultimate, затем повтори попытку.")
                .setPositiveButton("Понятно", null).show()
        }
    }

    private fun openLauncher() {
        val launch = packageManager.getLaunchIntentForPackage("com.example.homelauncher")
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Сначала установи HomeLauncher Ultimate", Toast.LENGTH_LONG).show()
    }
}
